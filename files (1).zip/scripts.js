document.addEventListener("DOMContentLoaded", function() {
    console.log("Dokument ist bereit!");
});